#!/usr/bin/env python3
"""Checks that every local file referenced by index.html / 404.html / CSS / JS exists.
Run from the project folder:  python3 tools/check_links.py"""
import re, os, sys
root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
bad = 0
def chk(src, ref):
    global bad
    ref = ref.split('#')[0].split('?')[0]
    if not ref or re.match(r'^(https?:|data:|mailto:|tel:|//)', ref): return
    if not os.path.exists(os.path.join(root, ref)):
        print('BROKEN:', src, '->', ref); bad += 1
for f in ['index.html', '404.html']:
    t = open(os.path.join(root, f), encoding='utf-8').read()
    for r in re.findall(r'(?:src|href)="([^"]+)"', t): chk(f, r)
for f in ['assets/css/style.css', 'assets/js/app.js']:
    t = open(os.path.join(root, f), encoding='utf-8').read()
    for r in re.findall(r'url\(["\']?([^)"\']+)', t): chk(f, r)
    for r in re.findall(r'img:"([^"]+)"', t): chk(f, r)
print('All local links OK' if not bad else f'{bad} broken link(s)')
sys.exit(1 if bad else 0)
