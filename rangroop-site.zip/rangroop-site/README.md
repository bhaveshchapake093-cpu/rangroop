# RANGROOP – Men's Fashion Website

Plain static website (HTML + CSS + JavaScript). No build step, no framework, no Claude/AI runtime needed.

```
index.html              main page
404.html                "page not found" page (GitHub Pages uses it automatically)
assets/css/style.css    all styling
assets/js/app.js        products, cart, filters, chat, sign-up demo
assets/images/          product photos
assets/favicon.svg      browser tab icon
optional/               GitHub Actions workflow (only if you want it)
tools/check_links.py    checks that no local file link is broken
```
All paths are **relative**, so the site works at `https://YOUR-USERNAME.github.io/rangroop/` and on any other host.

## Deploy on GitHub Pages (free, step by step)

1. Create a free account at https://github.com (skip if you have one).
2. Click **+ → New repository**. Name it exactly **rangroop**, set it to **Public**, and click **Create repository**.
3. On the new repo page click **uploading an existing file**.
4. Open the unzipped `rangroop-site` folder on your computer. Select **everything inside it** (index.html, 404.html, assets, optional, tools, README.md, robots.txt and the hidden `.nojekyll` file) and drag it into the GitHub page. Make sure `index.html` ends up at the top level of the repo, not inside another folder. Click **Commit changes**.
5. Go to **Settings → Pages**. Under **Build and deployment → Source** choose **Deploy from a branch**. Branch: **main**, folder: **/ (root)**. Click **Save**.
6. Wait 1 to 3 minutes and refresh the Pages settings. A box shows "Your site is live at https://YOUR-USERNAME.github.io/rangroop/".
7. Open that URL and run the checks below. Only after it opens correctly should you call the site published.

Tip: if the hidden `.nojekyll` file does not upload, create it on GitHub with **Add file → Create new file**, name it `.nojekyll`, leave it empty and commit. The site also works without it.

Optional: to deploy with GitHub Actions instead, set **Source: GitHub Actions** in Settings → Pages and move `optional/github-actions-pages.yml` to `.github/workflows/pages.yml`. Use one method, not both.

## Test it outside Claude

1. **Open the live URL** on a computer, an Android phone and an iPhone (Chrome, Safari, Firefox, Edge).
2. **Hard refresh** (Ctrl+Shift+R, or Cmd+Shift+R on Mac) to avoid old cached files.
3. **Console errors:** press F12 → Console. There should be no red errors.
4. **Broken files:** F12 → Network → refresh. No row should show 404 (red).
5. **Images:** all 13 product cards show a picture. The 3 photo products must load from `assets/images/`.
6. **Responsive:** F12 → toggle device toolbar (Ctrl+Shift+M) and try 360px, 768px and 1280px widths. Nothing should scroll sideways.
7. **Features:** choose a size → Add to Cart → open cart → change quantity → remove. Try search, the Diwali / Daily Wear filters and both price sorts. Open Quick View and the chat button.
8. **Links offline check:** run `python3 tools/check_links.py` inside the project folder. It should print "All local links OK".
9. **Run locally before uploading:** in the project folder run `python3 -m http.server 8000` and open http://localhost:8000.

## What works now, and what needs a backend

| Feature | Status |
|---|---|
| Product cards, categories, search, price filter, sorting | Works in the browser |
| Size and colour selection, Quick View, wishlist | Works in the browser |
| Cart (add, quantity, remove, coupon, totals) | Works in the browser, but resets when the page is refreshed |
| Sign up / Log in | **Demo only.** Nothing is saved and no account is created. Needs a backend and database (for example Firebase Auth or Supabase) |
| Checkout and orders | **Demo only.** No order is stored. Needs a backend and database |
| Payments (UPI, card, net banking) | **Not implemented.** Needs a payment gateway such as Razorpay or Cashfree plus a server |
| Order tracking, stock, inventory | **Not implemented.** Needs a backend |
| Newsletter sign-up | **Demo only.** Needs an email service |
| Chat box | Answers common questions from a fixed list. It does not store messages. A live AI or human chat needs an API or a service (WhatsApp, Tawk.to, etc.) |
| Product photos for Diwali and the other 7 products | Drawn illustrations. Replace them with real photos |

## Edit products

Open `assets/js/app.js` and find `var P=[`. Each line is one product: `n` name, `p` price, `c` category, `s` sizes, `col` colours, `d` description. To use a real photo, put the file in `assets/images/` and add `img:"assets/images/your-photo.webp"` to that product. Coupon and delivery settings are at the top of the same file (`COUPON`, `FREE_SHIP`, `SHIP`). Support email and phone are in the `CONTACT` line of the chat code. These are sample values, replace them with your real details.
