var COUPON={code:"DIWALI20",pct:20,min:500},FREE_SHIP=999,SHIP=79;
var SZ=["S","M","L","XL","XXL"],WZ=["28","30","32","34","36"];
/* PRODUCTS: edit names, prices, sizes, colours here. Optional: img (photo URL or data URI), mrp (shows a discount badge), tag (small label). */
var P=[
{id:1,n:"Maroon Festive Kurta",c:"Diwali",p:1299,s:SZ,f:1,col:[["Maroon","#7a1230"]],d:"Maroon kurta with white pajama in festive Indian styling.",a:{t:"kurta",tc:"#7a1230",b:"pyj",bc:"#f6f2e8",sh:"m"}},
{id:2,n:"Mustard Yellow Kurta",c:"Diwali",p:1499,s:SZ,col:[["Mustard","#d9a21b"]],d:"Mustard yellow festive kurta-pajama set.",a:{t:"kurta",tc:"#d9a21b",b:"pyj",bc:"#f6f2e8",sh:"m"}},
{id:3,n:"Royal Blue Embroidered Kurta",c:"Diwali",p:1799,s:SZ,col:[["Royal Blue","#1f3f9a"]],d:"Royal blue embroidered kurta with white trousers.",a:{t:"kurta",tc:"#1f3f9a",b:"trs",bc:"#f6f2e8",sh:"m",em:1}},
{id:4,n:"Cream Indo-Western Outfit",c:"Diwali",p:1999,s:SZ,f:1,col:[["Cream","#f1e4c3"]],d:"Cream kurta paired with a maroon Nehru jacket.",a:{t:"kurta",tc:"#f1e4c3",b:"trs",bc:"#efe3c6",sh:"m",j:"#7a1230"}},
{id:5,n:"Classic Black T-Shirt",c:"Daily Wear",p:399,s:SZ,f:1,col:[["Black","#141414"]],d:"Classic black T-shirt, styled with blue jeans and white sneakers.",a:{t:"tee",tc:"#141414",b:"jeans",bc:"#3d5f94",sh:"w"}},
{id:6,n:"Olive Casual Shirt & Cargo Pants",c:"Daily Wear",p:899,s:SZ,f:1,col:[["Olive","#6b7140"]],d:"Olive green overshirt with beige cargo pants.",a:{t:"over",tc:"#6b7140",b:"cargo",bc:"#cdb994",in:"#fff",sh:"b"}},
{id:7,n:"Oversized White T-Shirt",c:"Daily Wear",p:499,s:SZ,col:[["White","#f7f5f0"],["Beige","#d8c7a6"]],d:"Modern oversized T-shirt with a streetwear look.",a:{t:"tee",ov:1,tc:"#f7f5f0",b:"wide",bc:"#3a4660",sh:"w"}},
{id:8,n:"Checked Casual Shirt",c:"Daily Wear",p:699,s:SZ,col:[["Red Check","#b3262e"],["Blue Check","#2d5aa6"]],d:"Checked casual shirt, styled with dark blue jeans.",a:{t:"shirt",chk:1,tc:"#b3262e",b:"jeans",bc:"#1f2f55",sh:"w"}},
{id:9,n:"Slim Fit Blue Jeans",c:"Daily Wear",p:799,s:WZ,m:"b",col:[["Dark Blue","#1f3560"],["Black","#1a1a1a"]],d:"Dark blue slim-fit jeans, styled with a plain casual T-shirt.",a:{t:"tee",tc:"#cfd3d8",b:"jeans",bc:"#1f3560",sh:"w"}},
{id:10,n:"Beige Casual Trousers",c:"Daily Wear",p:699,s:WZ,m:"b",col:[["Beige","#cdb994"],["Olive","#78794a"]],d:"Beige trousers, styled with a premium casual shirt.",a:{t:"shirt",tc:"#f4f1ea",b:"trs",bc:"#cdb994",sh:"b"}},
{id:11,n:"Boston Raglan Oversized T-shirt",c:"Daily Wear",p:799,s:SZ,col:[["As shown","#d8c7a6"]],img:"assets/images/boston-raglan-tshirt.webp",d:"Cream and brown raglan sleeves, oversized fit, Boston print on the chest.",a:{t:"tee",ov:1,tc:"#d8c7a6",b:"jeans",bc:"#3d5f94",sh:"w"}},
{id:12,n:"Navy Contrast Ringer T-shirt",c:"Daily Wear",p:599,s:SZ,col:[["Navy","#1c2a4a"]],img:"assets/images/navy-ringer-tshirt.webp",d:"Navy relaxed-fit T-shirt with white contrast neck and sleeve trim.",a:{t:"tee",tc:"#1c2a4a",b:"jeans",bc:"#3d5f94",sh:"w"}},
{id:13,n:"Green Textured Polo T-shirt",c:"Daily Wear",p:999,s:SZ,col:[["Green","#1f5a45"]],img:"assets/images/green-textured-polo.webp",d:"Dark green textured polo with a white collar and small embroidery.",a:{t:"tee",tc:"#1f5a45",b:"jeans",bc:"#3d5f94",sh:"w"}}
];
var CATS=["All","Diwali","Daily Wear"];
var cat="All",cart={},wish={},coupon=0,user=null,sel={},$=function(i){return document.getElementById(i)};
function inr(n){return "₹"+Math.round(n).toLocaleString("en-IN")}
function byId(i){return P.filter(function(x){return x.id==i})[0]}
function S(i){return sel[i]||(sel[i]={s:"",c:0})}
function toast(m){var t=$("ts");t.textContent=m;t.classList.add("show");clearTimeout(toast.h);toast.h=setTimeout(function(){t.classList.remove("show")},1800)}
var SK="#d9a37c";
function art(x,c){
 var a=x.a,tc=x.m=="b"?a.tc:c,bc=x.m=="b"?c:a.bc,id="p"+x.id+c.slice(1),dw=x.c=="Diwali",E=' stroke="rgba(0,0,0,.3)" stroke-width="1.5"',hem=a.t=="kurta"?274:(a.t=="over"?262:252),lng=a.t!="tee",s;
 s='<svg viewBox="0 0 300 380" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="'+x.n+' (illustration)" preserveAspectRatio="xMidYMid slice"><defs><linearGradient id="'+id+'g" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="'+(dw?"#f8ecd2":"#f7f4ee")+'"/><stop offset="1" stop-color="'+(dw?"#e4c57f":"#dcd4c3")+'"/></linearGradient>'+(a.chk?'<pattern id="'+id+'c" width="16" height="16" patternUnits="userSpaceOnUse"><rect width="16" height="16" fill="'+tc+'"/><path d="M0 8H16M8 0V16" stroke="#fff" stroke-opacity=".6" stroke-width="4"/><path d="M0 0H16M0 0V16" stroke="#000" stroke-opacity=".3" stroke-width="2"/></pattern>':"")+'</defs><rect width="300" height="380" fill="url(#'+id+'g)"/>';
 if(dw)s+='<g fill="#c8942e" opacity=".55"><circle cx="38" cy="48" r="5"/><circle cx="264" cy="76" r="4"/><circle cx="56" cy="150" r="3"/><circle cx="256" cy="180" r="5"/><circle cx="34" cy="270" r="4"/><circle cx="268" cy="310" r="3"/></g>';
 var tf=a.chk?"url(#"+id+"c)":tc,sp=(a.b=="wide"||a.b=="cargo")?-8:(a.b=="jeans"?6:(a.b=="pyj"?3:4)),sh=a.sh=="w"?"#fff":(a.sh=="m"?"#9a6a2e":"#4a3524");
 s+='<circle cx="150" cy="52" r="24" fill="'+SK+'"/><path d="M126 50Q127 24 150 26Q173 24 174 50Q166 37 150 39Q135 37 126 50Z" fill="#1c1210"/><rect x="141" y="70" width="18" height="20" fill="'+SK+'"/>';
 s+=lng?'<circle cx="82" cy="214" r="8" fill="'+SK+'"/><circle cx="218" cy="214" r="8" fill="'+SK+'"/>':'<path d="M68 142L90 152L82 214L62 208ZM232 142L210 152L218 214L238 208Z" fill="'+SK+'"/>';
 s+='<path d="M104 215H196L'+(192-sp)+' 350H155L150 262L145 350H'+(108+sp)+'Z" fill="'+bc+'"'+E+'/>';
 if(a.b=="cargo")s+='<rect x="108" y="285" width="26" height="30" rx="3" fill="none"'+E+'/><rect x="166" y="285" width="26" height="30" rx="3" fill="none"'+E+'/>';
 if(a.b!="pyj")s+='<rect x="104" y="215" width="92" height="8" fill="rgba(0,0,0,.28)"/>';
 s+='<ellipse cx="'+(sp<0?123:127)+'" cy="356" rx="22" ry="9" fill="'+sh+'"'+E+'/><ellipse cx="'+(sp<0?177:173)+'" cy="356" rx="22" ry="9" fill="'+sh+'"'+E+'/>';
 var body=lng?'M92 96L120 86Q150 102 180 86L208 96L228 206L206 210L198 142L198 '+hem+'L102 '+hem+'L102 142L94 210L72 206Z':'M92 96L120 86Q150 102 180 86L208 96L234 140L208 152L198 136L198 238L102 238L102 136L92 152L66 140Z';
 s+='<g'+(a.ov?' transform="translate(150 0) scale(1.14 1) translate(-150 0)"':'')+'><path d="'+body+'" fill="'+tf+'"'+E+'/>';
 if(a.t=="over")s+='<path d="M138 92Q150 112 162 92L166 '+hem+'L134 '+hem+'Z" fill="'+(a.in||"#fff")+'"'+E+'/>';
 if(a.t=="tee")s+='<path d="M132 88Q150 110 168 88Z" fill="'+SK+'"'+E+'/>';
 if(a.t=="kurta"){s+='<path d="M138 89L150 118L162 89Z" fill="'+SK+'"/><path d="M150 118V200"'+E+'/><g fill="#c8942e"><circle cx="150" cy="130" r="3"/><circle cx="150" cy="150" r="3"/><circle cx="150" cy="170" r="3"/></g>'}
 if(a.t=="shirt"||a.t=="over"){s+='<path d="M134 88L150 112L142 124ZM166 88L150 112L158 124Z" fill="rgba(255,255,255,.6)"'+E+'/>';if(a.t=="shirt")s+='<path d="M150 112V'+hem+'"'+E+'/><g fill="#fff"'+E+'><circle cx="150" cy="135" r="2.5"/><circle cx="150" cy="165" r="2.5"/><circle cx="150" cy="195" r="2.5"/><circle cx="150" cy="225" r="2.5"/></g>';else s+='<path d="M134 124L134 '+hem+'M166 124L166 '+hem+'"'+E+'/>'}
 if(a.em)s+='<g stroke="#e0b44c" stroke-width="3" fill="none" stroke-dasharray="4 3"><path d="M138 89L150 118L162 89"/><path d="M102 270H198"/><path d="M72 206L94 210M228 206L206 210"/></g><g fill="#e0b44c"><circle cx="150" cy="140" r="3"/><circle cx="136" cy="152" r="3"/><circle cx="164" cy="152" r="3"/><circle cx="150" cy="164" r="3"/></g>';
 s+='</g>';
 if(a.j)s+='<path d="M106 98L130 90L150 124L170 90L194 98L196 262H104Z" fill="'+a.j+'" stroke="#c8942e" stroke-width="2.5"/><path d="M150 124V262" stroke="#c8942e" stroke-width="2"/><g fill="#c8942e"><circle cx="142" cy="150" r="3"/><circle cx="142" cy="180" r="3"/><circle cx="142" cy="210" r="3"/><circle cx="142" cy="240" r="3"/></g>';
 return s+'</svg>'}
function fb(el,id,ci){var x=byId(id);el.outerHTML=art(x,x.col[ci][1])}
function pic(x,ci){return '<div class="art">'+(x.img?'<img src="'+x.img+'" alt="'+x.n+'" onerror="fb(this,'+x.id+','+ci+')">':art(x,x.col[ci][1]))+'</div>'}
function opts(x,q){
 return '<div class="cl"><div class="sw" role="group" aria-label="Colour">'+x.col.map(function(c,i){return '<button type="button" data-col="'+i+'" style="background:'+c[1]+'" aria-label="'+c[0]+'" aria-pressed="'+(q.c==i)+'"></button>'}).join("")+'</div><span class="cn cc">'+x.col[q.c][0]+'</span></div><div class="cn">Select size</div><div class="sz" role="group" aria-label="Select size">'+x.s.map(function(z){return '<button type="button" data-sz="'+z+'" aria-pressed="'+(q.s==z)+'">'+z+'</button>'}).join("")+'</div>'}
function priceH(x){return inr(x.p)+(x.mrp?'<s>'+inr(x.mrp)+'</s><em>'+Math.round(100-x.p/x.mrp*100)+'% off</em>':'')}
function card(x){var q=S(x.id);
 return '<article class="card" data-id="'+x.id+'"><div class="pic" data-v="'+x.id+'">'+pic(x,q.c)+(x.tag?'<span class="tag">'+x.tag+'</span>':'')+'<button class="heart '+(wish[x.id]?"on":"")+'" data-w="'+x.id+'" aria-label="Add to wishlist">♥</button></div><div class="info"><div class="br">RANGROOP · '+x.c+'</div><h3>'+x.n+'</h3><div class="pr">'+priceH(x)+'</div>'+opts(x,q)+'<div class="act"><button class="add" data-a="'+x.id+'">Add to Cart</button><button class="qv" data-v="'+x.id+'">Quick View</button></div></div></article>'}
function sync(id){var q=S(id),x=byId(id);[].forEach.call(document.querySelectorAll('[data-id="'+id+'"]'),function(e){
 [].forEach.call(e.querySelectorAll("[data-sz]"),function(b){b.setAttribute("aria-pressed",b.dataset.sz==q.s)});
 [].forEach.call(e.querySelectorAll("[data-col]"),function(b){b.setAttribute("aria-pressed",b.dataset.col==q.c)});
 var cn=e.querySelector(".cc");if(cn)cn.textContent=x.col[q.c][0];
 var a=e.querySelector(".art");if(a&&!x.img)a.innerHTML=art(x,x.col[q.c][1])})}
function cats(){$("cats").innerHTML=CATS.map(function(c){return '<button class="'+(c==cat?"on":"")+'" data-cat="'+c+'">'+c+'</button>'}).join("")}
function list(){
 var q=$("q").value.toLowerCase(),pf=+$("pf").value,so=$("so").value;
 var a=P.filter(function(x){return(cat=="All"||x.c==cat)&&(x.n+" "+x.c+" "+x.d).toLowerCase().indexOf(q)>-1&&(!pf||(pf==99999?x.p>1500:x.p<=pf))});
 if(so=="lo")a.sort(function(x,y){return x.p-y.p});if(so=="hi")a.sort(function(x,y){return y.p-x.p});
 $("ttl").textContent=cat=="All"?"All products":cat+" Collection";
 $("grid").innerHTML=a.length?a.map(card).join(""):'<div class="empty">No products found. Try another search or category.</div>';
 $("feat").innerHTML=P.filter(function(x){return x.f}).map(card).join("")}
function badges(){$("cC").textContent=Object.values(cart).reduce(function(a,b){return a+b},0);$("cW").textContent=Object.keys(wish).length}
function sums(){var s=0;for(var k in cart)s+=byId(k.split("|")[0]).p*cart[k];var d=s*coupon,sh=(s-d>=FREE_SHIP||!s)?0:SHIP;return{s:s,d:d,sh:sh,t:s-d+sh}}
function drawer(mode){
 $("dt").textContent=mode=="w"?"Wishlist":"Your cart";
 var items=Object.keys(mode=="w"?wish:cart);
 if(!items.length){$("db").innerHTML='<div class="empty">'+(mode=="w"?"Your wishlist is empty. Tap ♥ to save products.":"Your cart is empty. Start your Diwali shopping!")+'</div>';$("df").innerHTML="";return}
 $("db").innerHTML=items.map(function(k){var a=k.split("|"),x=byId(a[0]);
  if(mode=="w")return '<div class="ci"><div class="t">'+pic(x,0)+'</div><div class="m"><b>'+x.n+'</b><br>'+inr(x.p)+'</div><button class="qv" style="padding:6px 12px" data-v="'+x.id+'">View</button><button data-r="'+k+'" data-mode="w" aria-label="Remove" style="font-size:22px">🗑</button></div>';
  return '<div class="ci"><div class="t">'+pic(x,a[2])+'</div><div class="m"><b>'+x.n+'</b><br><span class="cn">Size '+a[1]+' · '+x.col[a[2]][0]+'</span><br>'+inr(x.p)+'<br><span class="q"><button data-m="'+k+'" aria-label="Decrease">−</button><span>'+cart[k]+'</span><button data-p="'+k+'" aria-label="Increase">+</button></span></div><button data-r="'+k+'" data-mode="c" aria-label="Remove" style="font-size:22px">🗑</button></div>'}).join("");
 if(mode=="w"){$("df").innerHTML="";return}
 var m=sums();
 $("df").innerHTML='<div class="coupon"><input id="cp" placeholder="Coupon code" aria-label="Coupon"><button id="ap">Apply</button></div><div class="row"><span>Subtotal</span><span>'+inr(m.s)+'</span></div>'+(m.d?'<div class="row" style="color:#1a8a3a"><span>Coupon discount</span><span>−'+inr(m.d)+'</span></div>':'')+'<div class="row"><span>Delivery</span><span>'+(m.sh?inr(m.sh):"Free")+'</span></div><div class="row tot"><span>Total</span><span>'+inr(m.t)+'</span></div><button class="btn full" id="co" style="margin-top:10px">Checkout</button>'}
function open(mode){drawer(mode);$("dr").classList.add("show")}
function closeAll(){$("dr").classList.remove("show");[].forEach.call(document.querySelectorAll(".ov"),function(o){o.classList.remove("show")})}
function add(i){var q=S(i);
 if(!q.s){toast("Please select a size first");[].forEach.call(document.querySelectorAll('[data-id="'+i+'"] .sz'),function(e){e.classList.add("need");setTimeout(function(){e.classList.remove("need")},1000)});return}
 var k=i+"|"+q.s+"|"+q.c;cart[k]=(cart[k]||0)+1;badges();toast("Added to cart ✓");if($("dr").classList.contains("show"))drawer("c")}
function view(i){var x=byId(i),q=S(i);
 $("mP").innerHTML='<div data-id="'+i+'"><button class="x" data-close aria-label="Close">×</button><div class="pic">'+pic(x,q.c)+'</div><div class="br" style="margin-top:12px">RANGROOP · '+x.c+'</div><h3 style="font-size:28px">'+x.n+'</h3><p style="margin:4px 0">'+x.d+'</p><div class="pr" style="font-size:24px;margin:6px 0">'+priceH(x)+'</div>'+opts(x,q)+'<p class="note">Delivery in 2–4 days · 7-day returns</p><div class="act"><button class="add" data-a="'+i+'">Add to Cart</button><button class="qv" data-w="'+i+'">♥ Wishlist</button></div></div>';$("ovP").classList.add("show")}
function checkout(){var m=sums();$("mK").innerHTML='<button class="x" data-close aria-label="Close">×</button><h3 style="font-size:26px">Checkout</h3><p class="note">Demo checkout: no real payment is taken and no real order is created.</p><form class="fm" id="cf"><input required placeholder="Full name" value="'+(user||"")+'" aria-label="Name"><input required type="tel" pattern="[0-9]{10}" placeholder="Mobile (10 digits)" aria-label="Mobile"><input required placeholder="Address (house, street)" aria-label="Address"><div class="two"><input required placeholder="City" aria-label="City"><input required pattern="[0-9]{6}" placeholder="Pincode" aria-label="Pincode"></div><select aria-label="Payment"><option>UPI (GPay / PhonePe)</option><option>Credit / Debit card</option><option>Net banking</option><option>Cash on delivery</option></select><div class="row tot"><span>Amount to pay</span><span>'+inr(m.t)+'</span></div><button class="btn full">Place demo order</button></form>';$("dr").classList.remove("show");$("ovK").classList.add("show")}
var amode="up";
function auth(m){amode=m;var up=m=="up";$("at").textContent=up?"Sign up":"Log in";$("ap2").textContent=up?"Create an account to unlock Diwali offers and track your orders.":"Welcome back! Log in to continue shopping.";$("ln").style.display=up?"":"none";$("ln").required=up;$("ab").textContent=up?"Create account":"Log in";$("sw").textContent=up?"Already have an account?":"New to RANGROOP?";$("swb").textContent=up?"Log in":"Sign up";$("ovL").classList.add("show")}
document.addEventListener("click",function(e){
 var t=e.target,g=function(a){var n=t.closest("["+a+"]");return n?n.getAttribute(a):null},v,w;
 if(t.closest("[data-auth]")){auth(amode=="up"?"in":"up");return}
 if(t.closest("[data-close]")||t.classList.contains("ov"))return closeAll();
 if((v=g("data-go"))){cat=v;cats();list();$("shop").scrollIntoView({behavior:"smooth"});return}
 if((v=g("data-cat"))){cat=v;cats();list();return}
 if((v=g("data-sz"))){w=t.closest("[data-id]").dataset.id;S(w).s=v;sync(w);return}
 if((v=g("data-col"))){w=t.closest("[data-id]").dataset.id;S(w).c=+v;sync(w);return}
 if((v=g("data-w"))){wish[v]?delete wish[v]:wish[v]=1;badges();list();toast(wish[v]?"Added to wishlist ♥":"Removed from wishlist");return}
 if((v=g("data-a"))){add(v);return}
 if((v=g("data-v"))){closeAll();view(v);return}
 if((v=g("data-p"))){cart[v]++;badges();drawer("c");return}
 if((v=g("data-m"))){cart[v]--;if(!cart[v])delete cart[v];badges();drawer("c");return}
 if((v=g("data-r"))){var md=g("data-mode");delete (md=="w"?wish:cart)[v];badges();list();drawer(md);return}
 if(t.id=="ap"){var c=$("cp").value.trim().toUpperCase();if(c==COUPON.code&&sums().s>=COUPON.min){coupon=COUPON.pct/100;toast(COUPON.pct+"% discount applied 🎉")}else{coupon=0;toast(c==COUPON.code?"Spend at least "+inr(COUPON.min)+" to use this code":"Invalid coupon code")}drawer("c");return}
 if(t.id=="co")return checkout();
 if(t.closest("#bC"))return open("c");if(t.closest("#bW"))return open("w");if(t.closest("#bL"))auth("up")});
document.addEventListener("keydown",function(e){if(e.key=="Escape")closeAll()});
document.addEventListener("submit",function(e){e.preventDefault();var f=e.target;
 if(f.id=="lf"){user=$("ln").value||$("le").value.split("@")[0];$("bL").textContent="👤 "+user.split(" ")[0];closeAll();toast("Welcome, "+user+"!")}
 else if(f.id=="nf"){f.reset();toast("Subscribed. Thank you!")}
 else if(f.id=="cf"){var n="DEMO"+Math.floor(100000+Math.random()*900000);cart={};coupon=0;badges();$("mK").innerHTML='<div class="ok"><div class="big">🎉</div><h3 style="font-size:28px">Demo order complete</h3><p>Reference: <b>'+n+'</b><br>This is a demo store, so no payment was taken and no real order was created.</p><button class="btn" data-close style="border:0">Continue shopping</button></div>'}});
["q","pf","so"].forEach(function(i){$(i).addEventListener("input",list)});
function tick(){var end=new Date("2026-11-08T23:59:59+05:30"),d=end-new Date();if(d<0){$("cd").textContent="Sale ended";return}
  var p=function(n){return String(n).padStart(2,"0")};
  $("cd").innerHTML=[[Math.floor(d/864e5),"d"],[Math.floor(d/36e5)%24,"h"],[Math.floor(d/6e4)%60,"m"],[Math.floor(d/1e3)%60,"s"]].map(function(a){return "<span>"+p(a[0])+a[1]+"</span>"}).join("")}
tick();setInterval(tick,1000);var hist=[],greeted=false,CONTACT="support@rangroop.in or +91 98765 43210 (10 am to 7 pm, Mon to Sat)";
function say(t,w){var d=document.createElement("div");d.className="msg "+w;d.textContent=t;$("cm").appendChild(d);$("cm").scrollTop=1e9;return d}
function plist(){return P.map(function(x){return x.n+": "+inr(x.p)}).join("\n")}
var FAQ=[
[/return|refund|exchange|replace/,"You can return any item within 7 days of delivery if it is unused and has its tags. Refunds go to your original payment method in 5 to 7 days."],
[/deliver|shipping|ship |arrive|how long/,"Delivery takes 2 to 4 days across India. It is free above ₹999; below that, shipping is ₹79."],
[/pay|upi|cod|cash|card|gpay|phonepe/,"We accept UPI (GPay, PhonePe), credit/debit cards, net banking and cash on delivery."],
[/coupon|code|discount|offer|sale/,"Use code DIWALI20 for 20% off on orders above ₹500. "],
[/size|fit|measure/,"Tops come in S, M, L, XL and XXL, and jeans and trousers in waist sizes 28 to 36. Pick your size on the product card before adding to cart. If you are between sizes, choose the larger one."],
[/track|status|where.*order/,"Order tracking is not live yet in this demo store. Please contact "+CONTACT+"."],
[/price|cost|how much|product|t-?shirt|polo|collection|available/,function(){return "Here is what we have right now:\n"+plist()}],
[/contact|human|call|phone|email|agent|support/,function(){return "You can reach our team at "+CONTACT+"."}],
[/^(hi|hello|hey|hii|namaste)\b/,"Hello! 🪔 Happy Diwali. How can I help you today?"],
[/thank/,"You are welcome! Happy shopping 🪔"]];
async function ask(q){
  say(q,"u");hist.push("Customer: "+q);var low=q.toLowerCase(),a=null;
  FAQ.some(function(f){if(f[0].test(low)){a=typeof f[1]=="function"?f[1]():f[1];return true}});
  if(!a)a="I am not sure about that one. Please contact "+CONTACT+" and our team will help you.";
  say(a,"b");hist.push("Support: "+a)}
function toggleChat(){var c=$("chat");c.classList.toggle("show");
  if(c.classList.contains("show")){if(!greeted){greeted=true;say("Hi! 🪔 Welcome to RANGROOP. Ask me about delivery, returns, payments, offers or sizes, and I will help.","b");
    $("chips").innerHTML=["Delivery time","Return policy","Payment options","Offers","Size guide","Contact us"].map(function(c){return "<button type='button'>"+c+"</button>"}).join("")}
    $("chi").focus()}}
$("chBtn").addEventListener("click",toggleChat);
document.querySelector("[data-chat]").addEventListener("click",toggleChat);
$("chips").addEventListener("click",function(e){if(e.target.tagName=="BUTTON")ask(e.target.textContent)});
$("chf").addEventListener("submit",function(e){var v=$("chi").value.trim();$("chi").value="";if(v)ask(v)});
cats();list();badges();auth("up");
